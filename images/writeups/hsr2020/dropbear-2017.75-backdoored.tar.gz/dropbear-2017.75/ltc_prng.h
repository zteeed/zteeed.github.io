#ifndef DROPBEAR_LTC_PRNG_H_DROPBEAR
#define DROPBEAR_LTC_PRNG_H_DROPBEAR

#include "options.h"
#include "includes.h"

#ifdef DROPBEAR_LTC_PRNG

extern const struct ltc_prng_descriptor dropbear_prng_desc;

#endif /* DROPBEAR_LTC_PRNG */

#endif /* DROPBEAR_LTC_PRNG_H_DROPBEAR */
